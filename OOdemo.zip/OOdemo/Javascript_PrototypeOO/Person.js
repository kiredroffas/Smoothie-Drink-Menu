/**
 * OO Comparison Demo
 * CS320 Lecture 4
 * Xinghui Zhao
 * Fall 2018
 */

/**
 * This version is written in the "classic OO" style,
 * although the class construct is actually syntactic sugar which
 * is not really necessary.
 */

class Person {

  constructor(name) {
    this.name = name;
  }

  sayName(){
    console.log("My name is "+this.name);
  }
}

const tom = new Person("Tom");
tom.sayName();
