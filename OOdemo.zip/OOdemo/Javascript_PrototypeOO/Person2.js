/**
 * OO Comparison Demo
 * CS320 Lecture 4
 * Xinghui Zhao
 * Fall 2018
 */

/**
 * This version is written in the "prototype OO" style, which
 * is much simpler. No class is needed. You can create objects from
 * another object.
 *
 * Copy and paste this piece of code to JSfiddle, you can investigate
 * the objects in the console. 
 */

const tom = {name: "Tom",
            sayName: function(){
                console.log("My name is "+this.name);
            }
};


tom.sayName();

console.log(tom);

let tomy = Object.create(tom);
tomy.sayName();

console.log(tomy);
