/**
 * OO Comparison Demo
 * CS320 Lecture 4
 * Xinghui Zhao
 * Fall 2018
 */
public class Person {
  private String name;

  public Person(String name) {
    this.name = name;
  }

  public String getName() {
    return name;
  }

  public void sayName(){
    System.out.println("My name is "+name);
  }

  public static void main(String[] args) {
    Person p = new Person("Tom");
    p.sayName();
  }

}
